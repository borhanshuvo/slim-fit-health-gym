﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class ProgramController
    {
        public static DataBase db = new DataBase();
        public static void AddProgram(string programName, string nOD, string cost)
        {
            
                Programp p = new Programp()
                {
                    ProgramName = programName,
                    NumberOfDays = nOD,
                    ProgramCost = cost
                };
                db.Programs.AddProgram(p);

        }
        public static ArrayList GetAllPrograms()
        {
            return db.Programs.GetAllPrograms();
        }

    }
}
