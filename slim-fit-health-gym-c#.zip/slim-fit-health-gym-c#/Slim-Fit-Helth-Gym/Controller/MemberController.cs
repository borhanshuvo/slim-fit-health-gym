﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class MemberController
    {
        static DataBase db = new DataBase();
        public static void AddMember(string id,string name,string dOB, string gender, string email,string phone,string branch,string categoryName,string trainerId,string programName)
        {
            try
            {
                Member m = new Member()
                {
                    Id = id,
                    Name = name,
                    DOB = dOB,
                    Gender = gender,
                    Email = email,
                    Phone = phone,
                    Branch = branch,
                    CategoryName = categoryName,
                    TrainerId = trainerId,
                    ProgramName = programName,

                };
                db.Members.AddMember(m);
            }
            catch (Exception ex)
            { 

            }
   
        }
        public static void DeleteMember(string mId)
        {

            Member m = new Member()
            {
                Id = mId

            };
            db.Members.DeleteMember(m);
        }
        public static ArrayList GetAllMembers()
        {
            return db.Members.GetAllMembers();
        }
        
        public static ArrayList SearchMember(string searh)
        {

            return db.Members.GetAllMembersSearch(searh);
        }
    }
}
