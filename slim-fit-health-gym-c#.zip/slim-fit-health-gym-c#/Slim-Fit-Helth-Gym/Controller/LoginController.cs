﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class LoginController
    {

        public static DataBase db = new DataBase();
        static public bool AuthenticateUser(string ManagerName, string ManagerPassword)
        {
            bool result = false;

            var obj = db.Managers.AuthenticateUser(ManagerName, ManagerPassword);
            if (obj != null) result = true;
            return result;
        }
        static public bool AuthenticateUserAdmin(string adminName,string adminPassword)
        {
            bool result = false;

            var obj = db.Admins.AuthenticateUserAdmin(adminName, adminPassword);
            if (obj != null) result = true;
            return result;
        }


    }
}
