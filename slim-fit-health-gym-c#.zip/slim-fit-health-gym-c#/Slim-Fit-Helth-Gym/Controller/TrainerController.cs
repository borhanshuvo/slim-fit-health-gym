﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    
    class TrainerController
    {
        public int i =0;
        static DataBase db = new DataBase();
        public static ArrayList GetAllTraainers()
        {
            return db.Trainers.GetAlltrainers();
        }
        public static ArrayList GetAllTrainersSearch(string search)
        {
            return db.Trainers.GetAlltrainersSearch(search);
        }
        public static void AddTrainer(string tID,string tName,string tDOB,string tGender,string tEmail,string tPhone,string tBranch,string tSalary)
        {
            try
            {

                Trainer t = new Trainer()
                {
                    TrainerId = tID,
                    TrainerName = tName,
                    TrainerDOB = tDOB,
                    TrainerGender = tGender,
                    TrainerEmail = tEmail,
                    TrainerPhone = tPhone,
                    TrainerBranch = tBranch,
                    salary = Int32.Parse(tSalary)
                };
                db.Trainers.AddTrainer(t);
            }
            catch (Exception e)
            {
                
            }
            
            
            
        }
        public static void DeleteTrainer(string tId)
        {
            Trainer trainer = new Trainer()
            {
                TrainerId = tId,
            };
            db.Trainers.DeleteTrainer(trainer);
        }
    }
}
