﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class Programp
    {
        public string ProgramName { get; set; }
        public string ProgramCost { get; set; }
        public string NumberOfDays { get; set; }

    }
}
