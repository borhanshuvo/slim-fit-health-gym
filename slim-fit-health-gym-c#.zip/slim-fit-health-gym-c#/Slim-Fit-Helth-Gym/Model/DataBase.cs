﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class DataBase
    {
        public Admins Admins { get; set; }
        public Members Members { get; set; }
        public Managers Managers { get; set; }
        public Branches Branches { get; set; }
        public MemberCategories MemberCategories { get; set; }
        public Programs Programs { get; set; }
        public Trainers Trainers { get; set; }

        public DataBase()
        {
            Admins = new Admins();
            Managers = new Managers();
            Members = new Members();
            MemberCategories = new MemberCategories();
            Programs = new Programs();
            Trainers = new Trainers();
            Branches = new Branches();
        }

    }
}
