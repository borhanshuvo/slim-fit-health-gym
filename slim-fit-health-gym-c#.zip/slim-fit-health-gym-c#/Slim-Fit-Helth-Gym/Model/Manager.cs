﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class Manager
    {
        public int ManagerId { get; set; }
        public string ManagerName { get; set; }
        public string ManagerDOB { get; set; }
        public string ManagerAddress{ get; set; }
        //public string BranchName { get; set; }
        public string ManagerPassword { get; set; }

    }
}
