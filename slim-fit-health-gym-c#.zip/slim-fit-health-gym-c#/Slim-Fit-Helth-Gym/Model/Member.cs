﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class Member
    {
        

        public string Id { get; set; }
        public string Name { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Branch { get; set; }
        public string CategoryName { get; set; }

        public string TrainerId { get; set; }
        public string TrainerNames { get; set; }
        public string ProgramName { get; set; }
    }
}
