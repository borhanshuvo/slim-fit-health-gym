﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class Programs
    {
        SqlConnection conn;
        public Programs()
        {
            try
            {
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            }
            catch (Exception Ee)
            {

            }
        }
        public void AddProgram(Programp program)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO Programs (ProgramName,NoOfDays,Cost) VALUES('" + program.ProgramName + "','" + program.NumberOfDays + "','" + program.ProgramCost + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                conn.Close();
            }

        }
        public ArrayList GetAllPrograms()
        {
            ArrayList Programs = new ArrayList();
            conn.Open();
            string query = "SELECT * FROM Programs";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Programp p = new Programp()
                {
                    ProgramName= reader.GetString(reader.GetOrdinal("ProgramName")),
                    NumberOfDays= reader.GetString(reader.GetOrdinal("NoOfDays")),
                    ProgramCost= reader.GetString(reader.GetOrdinal("Cost"))
            
                };
                Programs.Add(p);
            }
            conn.Close();
            return Programs;

        }
    }
}
