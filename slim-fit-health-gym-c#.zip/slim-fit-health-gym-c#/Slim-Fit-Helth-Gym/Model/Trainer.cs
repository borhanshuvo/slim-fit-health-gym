﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slim_Fit_Helth_Gym.Model
{
    class Trainer
    {
        public string TrainerId { get; set; }
        public string TrainerName { get; set; }
        public string TrainerDOB { get; set; }
        public string TrainerGender { get; set; }
        public string TrainerEmail { get; set; }
        public string TrainerPhone { get; set; }
        public string TrainerBranch { get; set; }
        public int salary { get; set; }



    }
}
