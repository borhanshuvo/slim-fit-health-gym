﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Slim_Fit_Helth_Gym.Model
{
    class Branches
    {
        SqlConnection conn;
        public Branches()
        {
            try
            {
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            }
            catch (Exception Ee)
            {

            }
        }
        public void AddBranch(Branch branch)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO Branches (Place) VALUES('" + branch.Place + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                conn.Close();
            }
        }
        public ArrayList GetAllBranches()
        {
            ArrayList Branches = new ArrayList();

            conn.Open();
            string query = "SELECT * FROM Branches";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Branch b = new Branch();
                b.Place= reader.GetString(reader.GetOrdinal("Place"));
                Branches.Add(b);
            }
            conn.Close();
            return Branches;
        }
    }
}
