﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Slim_Fit_Helth_Gym.Model
{
    class MemberCategories
    {
        SqlConnection conn;
        public MemberCategories()
        {
            conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
        }
        public ArrayList GetAllMemberCategories()
        {
            ArrayList MemberCategories = new ArrayList();
            conn.Open();
            string query = "SELECT * FROM MemberCategories";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                MemberCategory mc = new MemberCategory()
                {
                    CategoryName = reader.GetString(reader.GetOrdinal("CategoryName")),
                    Duration = reader.GetString(reader.GetOrdinal("Duration")),
                    Discount = reader.GetInt32(reader.GetOrdinal("Discount")),
                   
                };

                MemberCategories.Add(mc);


            }
            conn.Close();
            return MemberCategories;
        }
    }
}
