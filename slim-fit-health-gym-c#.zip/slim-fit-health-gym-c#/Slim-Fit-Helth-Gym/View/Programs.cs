﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class Programs : Form
    {
        public Programs()
        {
            InitializeComponent();
        }

        private void Programs_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ProgramController.GetAllPrograms();
        }

        private void Programs_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Programs_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }

        private void buttonAddProgram_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddProgram().Show();
        }

        private void buttonAdminHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AdminHome().Visible = true;
        }
    }
}
