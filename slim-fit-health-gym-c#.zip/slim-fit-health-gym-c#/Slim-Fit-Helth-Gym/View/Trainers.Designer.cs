﻿namespace Slim_Fit_Helth_Gym.View
{
    partial class Trainers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBoxRemoveT = new System.Windows.Forms.TextBox();
            this.buttonRemoveB = new System.Windows.Forms.Button();
            this.buttonTadd = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonreg = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonBackAdmin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-7, 118);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(795, 244);
            this.dataGridView1.TabIndex = 0;
            // 
            // textBoxRemoveT
            // 
            this.textBoxRemoveT.Location = new System.Drawing.Point(12, 69);
            this.textBoxRemoveT.Name = "textBoxRemoveT";
            this.textBoxRemoveT.Size = new System.Drawing.Size(100, 20);
            this.textBoxRemoveT.TabIndex = 1;
            // 
            // buttonRemoveB
            // 
            this.buttonRemoveB.Location = new System.Drawing.Point(147, 69);
            this.buttonRemoveB.Name = "buttonRemoveB";
            this.buttonRemoveB.Size = new System.Drawing.Size(75, 23);
            this.buttonRemoveB.TabIndex = 2;
            this.buttonRemoveB.Text = "Remove";
            this.buttonRemoveB.UseVisualStyleBackColor = true;
            this.buttonRemoveB.Click += new System.EventHandler(this.buttonRemoveB_Click);
            // 
            // buttonTadd
            // 
            this.buttonTadd.Location = new System.Drawing.Point(713, 69);
            this.buttonTadd.Name = "buttonTadd";
            this.buttonTadd.Size = new System.Drawing.Size(75, 23);
            this.buttonTadd.TabIndex = 2;
            this.buttonTadd.Text = "Search";
            this.buttonTadd.UseVisualStyleBackColor = true;
            this.buttonTadd.Click += new System.EventHandler(this.buttontck);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(576, 72);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(100, 20);
            this.textBoxSearch.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(698, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Trainer List";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(12, 12);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 23);
            this.buttonBack.TabIndex = 4;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Visible = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonreg
            // 
            this.buttonreg.Location = new System.Drawing.Point(173, 11);
            this.buttonreg.Name = "buttonreg";
            this.buttonreg.Size = new System.Drawing.Size(87, 24);
            this.buttonreg.TabIndex = 5;
            this.buttonreg.Text = "Registation";
            this.buttonreg.UseVisualStyleBackColor = true;
            this.buttonreg.Click += new System.EventHandler(this.buttonreg_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(713, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "LogOut";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonBackAdmin
            // 
            this.buttonBackAdmin.Location = new System.Drawing.Point(330, 12);
            this.buttonBackAdmin.Name = "buttonBackAdmin";
            this.buttonBackAdmin.Size = new System.Drawing.Size(75, 23);
            this.buttonBackAdmin.TabIndex = 7;
            this.buttonBackAdmin.Text = "Home";
            this.buttonBackAdmin.UseVisualStyleBackColor = true;
            this.buttonBackAdmin.Visible = false;
            this.buttonBackAdmin.Click += new System.EventHandler(this.buttonBackAdmin_Click);
            // 
            // Trainers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonBackAdmin);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonreg);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonTadd);
            this.Controls.Add(this.buttonRemoveB);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.textBoxRemoveT);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Trainers";
            this.Text = "Trainers";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Trainers_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Trainers_FormClosed);
            this.Load += new System.EventHandler(this.Trainers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBoxRemoveT;
        private System.Windows.Forms.Button buttonRemoveB;
        private System.Windows.Forms.Button buttonTadd;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonreg;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.Button buttonBackAdmin;
        internal System.Windows.Forms.Button buttonBack;
    }
}