﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void AdminHome_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void AdminHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonProgram_Click(object sender, EventArgs e)
        {

            this.Hide();
            Programs p = new Programs();
            p.buttonAddProgram.Visible = true;
            p.Show();
            p.buttonAdminHome.Visible = true;


        }

        private void buttonAddBranch_Click(object sender, EventArgs e)
        {
            this.Hide();
            new BranchAdd().Show();
        }

        private void buttonManagerReg_Click(object sender, EventArgs e)
        {
            this.Hide();
            new RegistationManager().Show();
        }

        private void buttonManager_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Managers().Show();
        }

        private void ButtonTrainer_Click(object sender, EventArgs e)
        {
            this.Hide();
            Trainers t = new Trainers();
            t.Visible = true;
            t.buttonBackAdmin.Visible = true;
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }
    }
}
