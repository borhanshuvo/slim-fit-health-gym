﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class RegistationManager : Form
    {
        public RegistationManager()
        {
            InitializeComponent();
        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            ManagerController.AddManager(textBoxId.Text,textBoxName.Text,textBoxAddress.Text,textBoxDOB.Text,textBoxPaasord.Text);
        }

        private void RegistationManager_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void RegistationManager_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AdminHome().Show();
        }
    }
}
