﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class TrainerReg : Form
    {
        string gender;
        public TrainerReg()
        {
            InitializeComponent();
        }

        private void TrainerReg_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void TrainerReg_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonConfarm_Click(object sender, EventArgs e)
        {
            if (textBoxTrainerId.Text != "")
            {
                if (textBoxFirstName.Text != "")
                {
                    if (textBoxLastName.Text != "")
                    {
                        if (textBoxEmail.Text != "")
                        {
                            if (textBoxPhone.Text != "")
                            {
                                if (textBoxSalary.Text != "")
                                {
                                    dynamic b = comboBoxBranch.SelectedItem;
                                    string name = textBoxFirstName.Text + " " + textBoxLastName.Text;
                                    TrainerController.AddTrainer(textBoxTrainerId.Text, name, dateTimePickerDate.Text, gender, textBoxEmail.Text, textBoxPhone.Text, b.Place, textBoxSalary.Text);
                                    textBoxTrainerId.Text = "";
                                    
                                    textBoxEmail.Text = "";
                                    textBoxFirstName.Text = "";
                                    textBoxLastName.Text = "";
                                    textBoxSalary.Text = "";
                                    textBoxPhone.Text = "";
                                }
                                else
                                {
                                    MessageBox.Show("please insert First Salary", "Please try Again");
                                }
                            }
                            else
                            {
                                MessageBox.Show("please insert First Phone", "Please try Again");
                            }
                        }
                        else
                        {
                            MessageBox.Show("please insert Email", "Please try Again");
                        }
                    }
                    else
                    {
                        MessageBox.Show("please insert First LAst Name", "Please try Again");
                    }
                }
                else
                {
                    MessageBox.Show("please insert First Name", "Please try Again");
                }
            }
            else
            {
                MessageBox.Show("please insert Id", "Please try Again");
            }
            

        }

        private void checkBoxMale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void checkBoxFemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void TrainerReg_Load(object sender, EventArgs e)
        {
            comboBoxBranch.DataSource = BranchColtroller.GetAllBranches();
            comboBoxBranch.DisplayMember = "Place";
        }

        private void buttonT_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Trainers().Show();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }
    }
}
