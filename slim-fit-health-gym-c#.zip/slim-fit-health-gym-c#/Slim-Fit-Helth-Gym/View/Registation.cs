﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class Registation : Form
    {
        string Gender;
        public Registation()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }

        private void Registation_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Registation_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {

        }

        private void Registation_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonConfarm_Click(object sender, EventArgs e)
        {
            if (textBoxId.Text!="")
            {
                if (textBoxFirstName.Text != "")
                {
                    if (textBoxLastName.Text != "")
                    {
                        if (textBoxEmail.Text != "")
                        {
                            if (textBoxPhone.Text != "")
                            {
                                
                                string c = textBoxFirstName.Text + " " + textBoxLastName.Text;
                                dynamic com = comboBoxCategory.SelectedItem;
                                dynamic pm = comboBoxProgram.SelectedItem;
                                dynamic t = comboBoxTrainer.SelectedItem;
                                dynamic b = comboBoxBranch.SelectedItem;

                                MemberController.AddMember(textBoxId.Text, c, dateTimePicker1.Text, Gender, textBoxEmail.Text, textBoxPhone.Text, b.Place, pm.ProgramName, t.TrainerId, com.CategoryName);
                                textBoxId.Text = "";
                                textBoxFirstName.Text = "";
                                textBoxLastName.Text = "";
                                
                                textBoxEmail.Text = "";
                                textBoxPhone.Text = "";
                               

                            }
                            else
                            {
                                MessageBox.Show("please insert Phone Number", "Please try Again");
                            }
                        }
                        else
                        {
                            MessageBox.Show("please insert Email", "Please try Again");
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("please insert Last Name", "Please try Again");
                    }

                }
                else
                {
                    MessageBox.Show("please insert First name", "Please try Again");
                }
            }
            else
            {
                MessageBox.Show("please insert ID", "Please try Again");
            }


        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Registation_Load(object sender, EventArgs e)
        {
            //dynamic c = comboBoxCategory.SelectedItem;
            comboBoxCategory.DataSource = CategoryController.GetAllMemberCategories();
            comboBoxCategory.DisplayMember = "CategoryName";
            comboBoxProgram.DataSource= ProgramController.GetAllPrograms();
            comboBoxProgram.DisplayMember = "ProgramName";
            comboBoxTrainer.DataSource = TrainerController.GetAllTraainers();
            comboBoxTrainer.DisplayMember = "TrainerName";
            comboBoxBranch.DataSource = BranchColtroller.GetAllBranches();
            comboBoxBranch.DisplayMember = "Place";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonMemberClick(object sender, EventArgs e)
        {
            this.Hide();
            new ShowMember().Show();
        }

        private void buttonLogOutClick(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }

        private void radioButtonMale_Click(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void radioButtonFemale_Click(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void textBoxPtogramName_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxId_Click(object sender, EventArgs e)
        {
            textBoxFirstName.Text = "";
        }

        private void comboBoxBranch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
