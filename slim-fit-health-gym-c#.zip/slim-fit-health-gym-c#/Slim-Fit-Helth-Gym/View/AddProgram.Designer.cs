﻿namespace Slim_Fit_Helth_Gym.View
{
    partial class AddProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProgram));
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNOF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxCost = new System.Windows.Forms.TextBox();
            this.buttonConfarm = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(196, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Program Name";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(305, 77);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(195, 20);
            this.textBoxName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Number Of Days";
            // 
            // textBoxNOF
            // 
            this.textBoxNOF.Location = new System.Drawing.Point(305, 119);
            this.textBoxNOF.Name = "textBoxNOF";
            this.textBoxNOF.Size = new System.Drawing.Size(195, 20);
            this.textBoxNOF.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(196, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Cost";
            // 
            // textBoxCost
            // 
            this.textBoxCost.Location = new System.Drawing.Point(305, 160);
            this.textBoxCost.Name = "textBoxCost";
            this.textBoxCost.Size = new System.Drawing.Size(195, 20);
            this.textBoxCost.TabIndex = 1;
            // 
            // buttonConfarm
            // 
            this.buttonConfarm.Location = new System.Drawing.Point(425, 204);
            this.buttonConfarm.Name = "buttonConfarm";
            this.buttonConfarm.Size = new System.Drawing.Size(75, 23);
            this.buttonConfarm.TabIndex = 2;
            this.buttonConfarm.Text = "Confirm";
            this.buttonConfarm.UseVisualStyleBackColor = true;
            this.buttonConfarm.Click += new System.EventHandler(this.buttonConfarm_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Location = new System.Drawing.Point(323, 204);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(75, 23);
            this.buttonHome.TabIndex = 2;
            this.buttonHome.Text = "back";
            this.buttonHome.UseVisualStyleBackColor = true;
            this.buttonHome.Click += new System.EventHandler(this.buttonHomeClick);
            // 
            // AddProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonConfarm);
            this.Controls.Add(this.textBoxCost);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNOF);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddProgram";
            this.Text = "AddProgram";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddProgram_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddProgram_FormClosed);
            this.Load += new System.EventHandler(this.AddProgram_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNOF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxCost;
        private System.Windows.Forms.Button buttonConfarm;
        private System.Windows.Forms.Button buttonHome;
    }
}