﻿namespace Slim_Fit_Helth_Gym.View
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.buttonViewMember = new System.Windows.Forms.Button();
            this.buttonRegistation = new System.Windows.Forms.Button();
            this.buttonProgram = new System.Windows.Forms.Button();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.buttonCalanderShow = new System.Windows.Forms.Button();
            this.buttonCalanderHide = new System.Windows.Forms.Button();
            this.buttonTrainer = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttonMemberReg = new System.Windows.Forms.Button();
            this.buttonTrainerReg = new System.Windows.Forms.Button();
            this.groupBoxReg = new System.Windows.Forms.GroupBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.buttonBackReg = new System.Windows.Forms.Button();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.buttonPassChange = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxReg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonViewMember
            // 
            this.buttonViewMember.BackColor = System.Drawing.Color.Transparent;
            this.buttonViewMember.FlatAppearance.BorderSize = 0;
            this.buttonViewMember.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.buttonViewMember.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.buttonViewMember, "buttonViewMember");
            this.buttonViewMember.Name = "buttonViewMember";
            this.buttonViewMember.UseVisualStyleBackColor = false;
            this.buttonViewMember.Click += new System.EventHandler(this.button_View_memberClick);
            // 
            // buttonRegistation
            // 
            resources.ApplyResources(this.buttonRegistation, "buttonRegistation");
            this.buttonRegistation.Name = "buttonRegistation";
            this.buttonRegistation.UseVisualStyleBackColor = true;
            this.buttonRegistation.Click += new System.EventHandler(this.buttonRegistation_Click);
            // 
            // buttonProgram
            // 
            resources.ApplyResources(this.buttonProgram, "buttonProgram");
            this.buttonProgram.Name = "buttonProgram";
            this.buttonProgram.UseVisualStyleBackColor = true;
            this.buttonProgram.Click += new System.EventHandler(this.buttonProgram_Click);
            // 
            // buttonLogOut
            // 
            resources.ApplyResources(this.buttonLogOut, "buttonLogOut");
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.UseVisualStyleBackColor = true;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // monthCalendar1
            // 
            resources.ApplyResources(this.monthCalendar1, "monthCalendar1");
            this.monthCalendar1.Name = "monthCalendar1";
            // 
            // buttonCalanderShow
            // 
            resources.ApplyResources(this.buttonCalanderShow, "buttonCalanderShow");
            this.buttonCalanderShow.Name = "buttonCalanderShow";
            this.buttonCalanderShow.UseVisualStyleBackColor = true;
            this.buttonCalanderShow.Click += new System.EventHandler(this.buttonCalanderShowClick);
            // 
            // buttonCalanderHide
            // 
            resources.ApplyResources(this.buttonCalanderHide, "buttonCalanderHide");
            this.buttonCalanderHide.Name = "buttonCalanderHide";
            this.buttonCalanderHide.UseVisualStyleBackColor = true;
            this.buttonCalanderHide.Click += new System.EventHandler(this.buttonCalander_Click);
            // 
            // buttonTrainer
            // 
            this.buttonTrainer.BackColor = System.Drawing.Color.Transparent;
            this.buttonTrainer.FlatAppearance.BorderSize = 0;
            this.buttonTrainer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.buttonTrainer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.buttonTrainer, "buttonTrainer");
            this.buttonTrainer.Name = "buttonTrainer";
            this.buttonTrainer.UseVisualStyleBackColor = false;
            this.buttonTrainer.Click += new System.EventHandler(this.buttonTrainerClick);
            // 
            // buttonMemberReg
            // 
            resources.ApplyResources(this.buttonMemberReg, "buttonMemberReg");
            this.buttonMemberReg.Name = "buttonMemberReg";
            this.buttonMemberReg.UseVisualStyleBackColor = true;
            this.buttonMemberReg.Click += new System.EventHandler(this.buttonMemberReg_Click);
            // 
            // buttonTrainerReg
            // 
            resources.ApplyResources(this.buttonTrainerReg, "buttonTrainerReg");
            this.buttonTrainerReg.Name = "buttonTrainerReg";
            this.buttonTrainerReg.UseVisualStyleBackColor = true;
            this.buttonTrainerReg.Click += new System.EventHandler(this.buttonTrainerReg_Click);
            // 
            // groupBoxReg
            // 
            this.groupBoxReg.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxReg.Controls.Add(this.buttonTrainerReg);
            this.groupBoxReg.Controls.Add(this.buttonMemberReg);
            this.groupBoxReg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.groupBoxReg, "groupBoxReg");
            this.groupBoxReg.Name = "groupBoxReg";
            this.groupBoxReg.TabStop = false;
            this.groupBoxReg.Enter += new System.EventHandler(this.groupBoxRemobeMember_Enter);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.RoyalBlue;
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // buttonBackReg
            // 
            this.buttonBackReg.BackColor = System.Drawing.Color.LightGray;
            this.buttonBackReg.FlatAppearance.BorderSize = 0;
            this.buttonBackReg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.buttonBackReg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.buttonBackReg, "buttonBackReg");
            this.buttonBackReg.Name = "buttonBackReg";
            this.buttonBackReg.UseVisualStyleBackColor = false;
            this.buttonBackReg.Click += new System.EventHandler(this.buttonBackHomeClick);
            // 
            // dateTimePicker
            // 
            resources.ApplyResources(this.dateTimePicker, "dateTimePicker");
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            // 
            // buttonPassChange
            // 
            resources.ApplyResources(this.buttonPassChange, "buttonPassChange");
            this.buttonPassChange.Name = "buttonPassChange";
            this.buttonPassChange.UseVisualStyleBackColor = true;
            this.buttonPassChange.Click += new System.EventHandler(this.buttonPassChange_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Slim_Fit_Helth_Gym.Properties.Resources._20190203_082158;
            this.pictureBox1.Image = global::Slim_Fit_Helth_Gym.Properties.Resources._20190203_0821581;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // HomePage
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Slim_Fit_Helth_Gym.Properties.Resources.images__1_;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonPassChange);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.buttonCalanderHide);
            this.Controls.Add(this.buttonCalanderShow);
            this.Controls.Add(this.buttonBackReg);
            this.Controls.Add(this.groupBoxReg);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.buttonTrainer);
            this.Controls.Add(this.buttonViewMember);
            this.Controls.Add(this.buttonLogOut);
            this.Controls.Add(this.buttonProgram);
            this.Controls.Add(this.buttonRegistation);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "HomePage";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HomePage_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.HomePage_FormClosed);
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.groupBoxReg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonRegistation;
        private System.Windows.Forms.Button buttonProgram;
        private System.Windows.Forms.Button buttonViewMember;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button buttonCalanderShow;
        private System.Windows.Forms.Button buttonCalanderHide;
        private System.Windows.Forms.Button buttonTrainer;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button buttonMemberReg;
        private System.Windows.Forms.Button buttonTrainerReg;
        private System.Windows.Forms.GroupBox groupBoxReg;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button buttonBackReg;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button buttonPassChange;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}